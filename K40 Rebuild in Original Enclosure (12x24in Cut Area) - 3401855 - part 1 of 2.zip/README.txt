K40 Rebuild in Original Enclosure (12x24in Cut Area) by Hawking on Thingiverse: https://www.thingiverse.com/thing:3401855

Summary:
This is my version of a K-40 Laser Cutter Rebuild.  I bought a K-40 about a year ago and was never satisfied with the cutting area or quality of the mechanics.  It was super tight, but I achieved 12.5 x 24.25 in of cutting area by allowing most of the mechanics to slide under the laser tube housing.  For a detailed build log, BOM and others, please visit:www.ReplicantFX.com