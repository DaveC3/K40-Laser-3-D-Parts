K40 4-Wheel head carriage modification 20x40 extrusion by BillsCNC on Thingiverse: https://www.thingiverse.com/thing:4744057

Summary:
4-Wheel Head Carriage for 20x40 V-Slot ExtrusionThis is a remix from https://www.thingiverse.com/thing:3401855Using four wheels makes the head much more stable. The spacer is used for a Cloudray setup.